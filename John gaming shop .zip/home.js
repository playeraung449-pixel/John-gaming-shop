function loadUserName() {
  const userId = "USER_ID"; // ← သင့် user ID ကိုသတ်မှတ်ပါ

  db.ref("users/" + userId + "/name").once("value")
    .then((snapshot) => {
      const name = snapshot.val() || "JUCK";
      document.getElementById("welcome").innerText = "မင်္ဂလာပါ " + name;
    })
    .catch((error) => {
      console.error("Name load error:", error);
    });
}

function updateBalance(prizeAmount) {
  const userId = "USER_ID"; // သင့် user ID
  const db = firebase.database();

  // ငွေလက်ကျန် fetch
  db.ref("users/" + userId + "/balance").once("value").then((snapshot) => {
    const currentBalance = snapshot.val() || 0;
    const newBalance = currentBalance + prizeAmount;

    // update to Firebase
    db.ref("users/" + userId + "/balance").set(newBalance);
  });
}
function loadBalance() {
  const userId = "USER_ID";
  const db = firebase.database();

  db.ref("users/" + userId + "/balance").on("value", (snapshot) => {
    const balance = snapshot.val() || 0;
    document.getElementById("balance").innerText = balance + " Ks";
  });
}
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
  projectId: "YOUR_PROJECT_ID"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.database();

// ✅ Detect login user
auth.onAuthStateChanged(user => {
  if (user) {
    const uid = user.uid;
    document.getElementById("userId").innerText = "ID: " + uid;

    // ✅ Load user info from Firebase
    db.ref("users/" + uid).once("value").then(snapshot => {
      const data = snapshot.val();
      document.getElementById("userName").innerText = "နာမည်: " + (data?.name || "မသတ်မှတ်ရသေးပါ");
      document.getElementById("profilePic").src = data?.profilePic || "https://via.placeholder.com/120";
    });
  } else {
    window.location.href = "login.html"; // redirect if not logged in
  }
});

// ✅ Upload profile pic
function uploadProfilePic(file) {
  const uid = auth.currentUser.uid;
  const reader = new FileReader();
  reader.onload = function(e) {
    const imageUrl = e.target.result;
    document.getElementById("profilePic").src = imageUrl;
    db.ref("users/" + uid).update({ profilePic: imageUrl });
  };
  reader.readAsDataURL(file);
}