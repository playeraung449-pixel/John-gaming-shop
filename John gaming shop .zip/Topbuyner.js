// Firebase config
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT_ID.firebaseio.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

// Load Top Buyers
function loadTopBuyers() {
  db.ref("topBuyers").once("value").then((snapshot) => {
    const data = snapshot.val();
    const buyers = [];

    for (let key in data) {
      const buyer = data[key];
      if (buyer.active) {
        buyers.push({
          name: buyer.name,
          totalSpent: buyer.totalSpent
        });
      }
    }

    // Sort by totalSpent descending
    buyers.sort((a, b) => b.totalSpent - a.totalSpent);

    // Take top 10
    const top10 = buyers.slice(0, 10);

    // Render to UI
    const list = document.getElementById("buyerList");
    list.innerHTML = "";

    top10.forEach((buyer, index) => {
      const card = document.createElement("div");
      card.className = "buyer-card" + (index === 0 ? " gold" : "");

      card.innerHTML = `
        <div class="rank">#${index + 1}</div>
        <div class="name">${buyer.name}</div>
        <div class="amount">${buyer.totalSpent} Ks</div>
      `;

      list.appendChild(card);
    });
  });
}

// Run on page load
window.onload = loadTopBuyers;