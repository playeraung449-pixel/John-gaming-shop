db.ref("users").push(userData)
  .then(() => {
    alert("Account created successfully ✅");
    window.location.href = "login.html"; // ← Login page ကိုပြန်ပို့တယ်
  })
  .catch((error) => {
    console.error("Error:", error);
    alert("Failed to create account ❌");
  });
  db.ref("orders").once("value").then(snapshot => {
  const orders = snapshot.val();
  for (const uid in orders) {
    for (const orderId in orders[uid]) {
      const order = orders[uid][orderId];
      if (order.type === "FreeFire" && order.status === "pending") {
        // Render row with approve/retry buttons
      }
    }
  }
});

function approveOrder(uid, orderId, order) {
  db.ref(`orders/${uid}/${orderId}/status`).set("delivered");
  fetch("https://your-bot-api.com/sendFreeFireDiamond", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      uid: uid,
      diamond: order.amount,
      price: order.price,
      playerId: order.playerId,
      accountName: order.accountName,
      telegram: order.telegram || ""
    })
  });
}
auth.onAuthStateChanged(user => {
  if (user) {
    // အကောင့်ဝင်ထားပြီးသား — မလုပ်စရာမလို
    console.log("User already logged in:", user.uid);
  } else {
    // မဝင်ရသေး — login.html ပြန်ပို့
    window.location.href = "login.html";
  }
});