// "အခြားဝန်ဆောင်မှု" button ကို နှိပ်လိုက်တာနဲ့ Telegram section ကို animate လုပ်ပြီး ပြမယ်
document.querySelector('button:nth-child(4)').addEventListener('click', function() {
  const telegramSection = document.getElementById('telegramSection');

  if (telegramSection.classList.contains('hidden')) {
    // ပထမဆုံး display ပြန်ဖွင့်
    telegramSection.classList.remove('hidden');
    
    // နည်းနည်း delay ပေးပြီး animation class ထည့် (browser reflow အတွက်)
    setTimeout(() => {
      telegramSection.classList.add('animated');
    }, 10);
  } else {
    // ပြန်ဖျောက်မယ်ဆိုရင်
    telegramSection.classList.remove('animated');
    setTimeout(() => {
      telegramSection.classList.add('hidden');
    }, 300); // animation ပြီးမှ ဖျောက်မယ်
  }
});